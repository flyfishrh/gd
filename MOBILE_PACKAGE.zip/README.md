# 手机推理模型包 short_train_v1

包含四个经真实短训的 FP32 actor：models/actor_seat0.onnx ～ actor_seat3.onnx。每个约9.57MB，适合通过 ONNX Runtime 在 iOS/Android App 内加载；真机尚未验证。Critic 不参与手机动作推理。完整训练 checkpoint 单独保留在同目录 trained_checkpoint.pt，不打入精简手机 ZIP。

输入 float32：state[1,673]，history[1,T,673]（1≤T≤40），h/c[2,1,256]。输出 raw_logits[1,336]、next_h/c[2,1,256]。每个座位独立 session/历史/循环状态/RNG。请按 FEATURE_ACTION_CONTRACT.json 与原始编码/保留槽/聚合/解码规则接入；不能将336个输出当成 CardID。不要添加看起来合理的新历史特征或改 HR 编码。

桌面独立复核（已在本环境执行；只需 NumPy 与 ONNX Runtime，不需要 Torch）：

```sh
python deployment_reference.py
```

该脚本对四个真实公开 fixture 校验模型输出，并给出原始合法动作。feature_encoder.py 只用 AST 抽取已审计源文件中的指定编码/parse方法，经 NumPy shim 执行，不执行 vendor 原始 import 或训练器。reference_seat*.npz 用 allow_pickle=False 读取。生产端可按这些可运行参考用 Swift/Kotlin/C++/JS 重写编码与解码，并逐 fixture 对照。

手机接入步骤：
1. 使用官方 ONNX Runtime iOS/Android 包，将对应座位 ONNX 加入 App 资源；使用完整 CPU runtime 起步，后续再验证裁剪包/加速器。
2. 创建 session，确认四个输入和三个输出的名称/float32形状；batch 固定1，T按实际历史长度。
3. 从已验证的公开游戏状态与完整合法动作列表编码 state；准备该座位以前最多40个状态及 h/c。
4. 推理后按契约聚合、mask、argmax与原始 decoder 选择合法动作；保存 next_h/c，并将本次 state 追加历史。
5. 单独实现并验证目标游戏动作/CardID/重复实体牌映射，再做真机测试。本包没有读取或修改生产工程，不是当前游戏即插即用插件。

官方移动部署文档：https://onnxruntime.ai/docs/tutorials/mobile/ ，https://onnxruntime.ai/docs/get-started/with-mobile.html 。此处不宣称任何真机/棋力提升 PASS。

文件完整性见 MODEL_MANIFEST.json、PACKAGE_CONTENTS.json 与外部 DELIVERY_MANIFEST.json。上游源文件 MIT 许可随 vendor_source/LICENSE 保留；来源提交见 SOURCE_PROVENANCE.json。
