"""Independent NumPy + ONNX Runtime reference; no Torch or unsafe checkpoint load.
The host supplies original-engine public DTO and its complete legal action list.
This reference is a porting specification, not a production CardID adapter.
"""
import json,pathlib,random,collections
import numpy as np
import onnxruntime as ort
from feature_encoder import create,encode
ort.disable_telemetry_events()
ROOT=pathlib.Path(__file__).resolve().parent
def normalize_dto(dto):
 dto=dict(dto)
 for key in ('played_cards','min_steps_estimation'):
  if isinstance(dto.get(key),dict):dto[key]={int(k):v for k,v in dto[key].items()}
 return dto
def legal_decode(a,dto,raw,seed):
 parsed=a.parse(normalize_dto(dto));actions=parsed['actionList']
 _,indices=a.state_encoder.create_action_features(parsed,actions);_,mapping=a.abstract_action_space(actions)
 retained={};scores=np.full(336,-1e9,dtype=np.float32);trump=parsed.get('curRank')
 for orig in indices:
  group=next(g for g,ids in mapping.items() if orig in ids)
  if group>=336:raise ValueError('ABSTRACT_GROUP_OVERFLOW')
  retained.setdefault(group,[]).append(orig)
 for group,ids in retained.items():
  normal=[];special=[]
  for orig in ids:
   action=actions[orig];slot=indices.index(orig)
   if slot>=336:continue
   has=bool(trump) and len(action)>2 and isinstance(action[2],list) and any(isinstance(c,str) and len(c)>=2 and c[0]=='H' and c[1:]==trump for c in action[2])
   (special if action[0]=='StraightFlush' or has else normal).append(float(raw[slot]))
  selected=normal or special
  if selected:scores[group]=np.mean(selected)
 if not np.any(scores>-1e9):raise ValueError('NO_REPRESENTABLE_LEGAL_ACTION')
 group=int(scores.argmax());ordinary=[];hearts=[];sf=[]
 for orig in retained[group]:
  action=actions[orig];has=bool(trump) and len(action)>2 and isinstance(action[2],list) and any(isinstance(c,str) and len(c)>=2 and c[0]=='H' and c[1:]==trump for c in action[2])
  (sf if action[0]=='StraightFlush' else hearts if has else ordinary).append(orig)
 pool=ordinary or hearts or sf
 if not pool:raise ValueError('NO_LEGAL_DECODE_CANDIDATE')
 index=random.Random(seed).choice(pool)
 return {'abstractGroup':group,'originalIndex':index,'action':actions[index]}
class MobilePolicy:
 def __init__(self,seat):
  self.seat=seat;self.encoder=create(seat,'R0');self.history=collections.deque(maxlen=40)
  self.h=np.zeros((2,1,256),dtype=np.float32);self.c=self.h.copy()
  options=ort.SessionOptions();options.intra_op_num_threads=2;options.inter_op_num_threads=1
  self.session=ort.InferenceSession(str(ROOT/'models'/('actor_seat'+str(seat)+'.onnx')),sess_options=options,providers=['CPUExecutionProvider'])
 def reset(self):self.history.clear();self.h.fill(0);self.c.fill(0)
 def choose(self,dto,seed):
  dto=normalize_dto(dto);x=encode(self.encoder,dto).reshape(1,673).astype(np.float32)
  hist=np.stack(self.history,axis=0)[None,:,:] if self.history else np.zeros((1,1,673),dtype=np.float32)
  raw,self.h,self.c=self.session.run(None,{'state':x,'history':hist,'h':self.h,'c':self.c})
  action=legal_decode(self.encoder,dto,raw[0],seed);self.history.append(x[0].copy());return action
def verify_fixture(seat):
 p=MobilePolicy(seat);d=np.load(ROOT/('reference_seat'+str(seat)+'.npz'),allow_pickle=False)
 actual=p.session.run(None,{k:d[k] for k in ('state','history','h','c')})[0]
 assert np.allclose(actual,d['raw_logits'],atol=2e-4,rtol=2e-4)
 dto=json.loads((ROOT/('reference_seat'+str(seat)+'.json')).read_text());dto=normalize_dto(dto)
 assert np.array_equal(encode(p.encoder,dto),d['state'][0])
 return legal_decode(p.encoder,dto,actual[0],202610239)
if __name__=='__main__':
 for seat in range(4):print(json.dumps({'seat':seat,'fixture':'PASS','legalDecision':verify_fixture(seat)}))
