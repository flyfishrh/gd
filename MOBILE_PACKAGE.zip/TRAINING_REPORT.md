# 真实短训报告

状态：PASS_REAL_SHORT_FINE_TUNING。基于已验证 PerfectDan 原始权重，对四个座位分别进行了真实行为克隆微调；不是 PPO，也不证明棋力提高。

原始引擎公开信息自博弈由 Base7 给出真实合法决策，共512样本；每个座位32次 Adam 更新、batch8、lr=1e-5、梯度裁剪0.5。每座位选取样本最多的等长历史桶（T40）训练，训练上下文 h/c 来自冻结的原始策略沿老师轨迹的前向计算。目标为原始动作聚合后的老师抽象组交叉熵。所有损失/梯度有限，每个 actor 的14个参数张量发生变化。Critic 完全不变；原始 checkpoint 未覆盖。

| 座位 | 收集样本 | 更新数 | 首次 → 最后 batch loss | 参数差 L2 |
|---|---:|---:|---:|---:|
| 0 | 138 | 32 | 2.249133 → 0.980643 | 0.123012885 |
| 1 | 135 | 32 | 1.430393 → 1.455079 | 0.139482508 |
| 2 | 115 | 32 | 1.257880 → 1.205576 | 0.125381399 |
| 3 | 124 | 32 | 0.914104 → 0.862717 | 0.109345115 |

不同 batch 的首末损失不可当作同一验证集指标；座位1的末次损失略高，保留如实结果。未进行强度评测、训练收敛评估或生产回归。

目标、种子、样本/更新上限先记录在 PREREGISTRATION.json。原始 PPO updater 与当前 forward 签名不兼容，采用已获授权的最小行为克隆路线，无上游规则/策略修复。第一次 helper 缺 state_dim 的失败日志保留，修正仅发生在研究 harness。

安全：Torch2.14.1+cpu；今日官方安全审计见既有 evidence/cloud_preparation_02/SECURITY_ADVISORY_AUDIT.json。checkpoint 只以 weights_only=True、CPU、strict state_dict 加载；没有 unsafe loader/safe_globals。使用显式非秘密环境、close_fds、研究 cwd，两个数值线程、受监督进程与4GB RSS 监测上限。本任务经 Owner 新授权放宽旧离线/文件系统隔离前置条件；不声称强制离线或完全文件系统隔离。没有读取凭据值或生产文件，没有公开上传。

详细记录：TRAINING_QA.json、TRAINING_STEPS.jsonl、DATA_QA.json、SAFE_LOAD_QA.json。训练后完整 checkpoint 为旁置 trained_checkpoint.pt；模型与其对应的 tensor SHA 见 MODEL_MANIFEST.json。
