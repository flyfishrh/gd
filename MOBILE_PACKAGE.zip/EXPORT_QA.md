# 导出验证

PASS：四个独立座位 FP32 ONNX actor，opset17，每个9,568,406字节。使用显式 h/c 的 legacy ONNX exporter（dynamo=False），固定 batch1、动态 T1..40；未使用反序列化回退。四个网络严格加载新训练参数后导出，对应 tensor SHA 与 TRAINING_QA 完全一致。

PyTorch/ONNX Runtime CPU 共284组对照：原始26个公开 golden ×4座位=104；真实上下文20；每个座位全部 T1..40=160。额外执行了各座位多步 h/c 回传。logits/h/c 最大绝对误差分别为 [1.341104507446289e-07, 1.7881393432617188e-07, 4.76837158203125e-07]，均小于 atol=rtol=2e-4。相同公开上下文、合法列表、原始 decoder 和 RNG 下，所有合法动作选择一致。

另104组对照确认 NumPy 特征参考与原始 Torch 编码字节一致，独立 NumPy decoder 与原始 decoder 一致；四个 Torch-free ORT fixture 示例成功。训练 actor 参数均有限，Critic 张量与原始 checkpoint 完全一致。

版本见 EXPORT_INSTALLED_QA.json，官方 PyPI wheel 版本/来源/SHA 见 EXPORT_WHEEL_MANIFEST.json；隔离导出 venv 共享既有审计 runtime，只补装5个二进制依赖，无 Torch 降级，pip check 通过。ORT 初次验证产生用户目录 telemetry ID 持久化警告（未输出ID），部署参考显式 disable_telemetry_events；不将该警告作为离线证明。

未测试：iOS/Android 真机、NNAPI/CoreML、量化、批大小>1、T>40、游戏强度、当前项目 CardID/动作桥接、Native/生产集成。ONNX 的通用手机运行能力不等于目标游戏已经接入。
